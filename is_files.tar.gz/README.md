# is_sitelock

A site lock tool for secure wordpress websites.  

This was designed as part of a walkthrough on cpanel plugin tool to help server admins to protect thier websites hosting.
